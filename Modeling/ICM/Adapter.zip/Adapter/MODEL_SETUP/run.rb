require 'date'
require 'FileUtils'

# class to override the to_s method of the date.DateTime object.
class DateTime
	def to_s
		return strftime('%Y-%m-%d %H:%M:%S')
	end
end

# class to make a unique identifier to use in run name
def new_guid
	#sprintf('%s', rand(36**8).to_s(36).upcase)
	sprintf('%s', DateTime.now().to_s())
end 



print("starting...\n")

# getting some variables
scriptfolder = File.dirname(WSApplication.script_file)
original_results_folder = WSApplication.results_folder
original_working_folder = WSApplication.working_folder

# print folders at startup
print("script folder: ", scriptfolder, "\n")
print("original working folder: ", original_working_folder, "\n")
print("original results folder: ", original_results_folder, "\n")

# determining the location of the script folder - assume it is the root
# this has to be modfied depending upon the organisation of files
root_folder = scriptfolder

# print the root location
print("root folder: ", root_folder, "\n")

# making paths for the session -  and creating the directories if they do not exist
workingfolder = root_folder + "\\working"
resultsfolder = root_folder + "\\results"
exportfolder = root_folder + "\\export"
Dir.mkdir(workingfolder) unless File.exists?(workingfolder)
Dir.mkdir(resultsfolder) unless File.exists?(resultsfolder)
Dir.mkdir(exportfolder) unless File.exists?(exportfolder)

# tell ICM which directories to use
WSApplication.set_results_folder resultsfolder
WSApplication.set_working_folder workingfolder
print("working folder: ", WSApplication.working_folder, "\n")
print("results folder: ", WSApplication.results_folder, "\n")

begin
	# open the database - assume it is called modelsetup.icm
	dbfile = root_folder + "\\modelsetup.icmm"
	print("opening DB " + dbfile + "\n")
	db = WSApplication.open dbfile, false

	dummyinflow = '>MODG~Test>MODG~Ermington Representative>INF~Dummy Inflow'
	rootgroup = db.model_object '>MODG~Test'
	modelgroup = db.model_object '>MODG~Test>MODG~Ermington Representative'

	# replace inflow data with data from import folder
	dummyinflow_path = root_folder + "\\import\\Dummy Inflow.csv"
	print("replacing inflow from " + dummyinflow_path +"\n")
	mo_dummyinflow = db.model_object(dummyinflow)
	mo_dummyinflow.import_tvd(dummyinflow_path,"CSV",0)

	# get start date from csv-data and use that
	start = DateTime.new(2018,2,26,12,0,0)
	i=0
	lines = File.readlines(dummyinflow_path )
	lines.each do |line|
		i = i + 1
		if i == 7
			startx = line.split(",")[0]
			start = DateTime.strptime(startx, '%d/%m/%Y %H:%M:%S')
			print("Found start time " + start.to_s() + "\n")
		end 
	end
	endx = lines[-1].split(",")[0]
	endtime = DateTime.strptime(endx, '%d/%m/%Y %H:%M:%S')
	print("Found end time " + endtime.to_s() + "\n")
	dur = ((endtime-start)*24*60).to_i
	print("Duration ", dur, " minutes\n")

	runParamsHash = Hash.new
	runParamsHash['ExitOnFailedInit']=true
	runParamsHash['Inflow']=dummyinflow
	runParamsHash['TimeStep']=2   #secs
	runParamsHash['ResultsMultiplier']=450
	runParamsHash['Duration'] = dur   # minutes
	#runParamsHash['DurationUnit']='Hours'
	runParamsHash['StorePRN']=true
	runParamsHash['Start Time'] = start #DateTime.parse(2018,2,26,12,0,0)
	#runParamsHash['Save Final State']=true

	# make new run
	g = new_guid()
	runname = 'ICMExchange Run #'+g
	network = '>MODG~Test>MODG~Ermington Representative>NNET~Ermington Network'
	run = modelgroup.new_run(runname, network, 9, nil, nil, runParamsHash)

	# start simulation	
	# create an array of simulations to start (only one)
	simsArray=Array.new
	sim=run.children[0]
	simsArray << sim

	# wake up the agent to run the simulations
	WSApplication.connect_local_agent(10)

	# wake up the agent to run the simulations
	handles=WSApplication.launch_sims simsArray,'.', false, 0, 0
	i=0
	while sim.status=='None' or sim.status =='Active'
		print(sim.status,i,"\n")
		sleep 1
		i = i + 1
	end
	puts sim.status	
	if sim.status=="Success"
		puts sim.success_substatus

		# export all results
		sim.results_csv_export(nil,exportfolder)
	end
	print(sim.timestep_count," timesteps\n")


	# create a transportable database will all results
	transpath = root_folder + "\\modelsetup.icmt"
	print("making transportable database " + transpath + "\n")
	WSApplication.create_transportable(transpath)
	transdb = WSApplication.open transpath, false
	mo = transdb.copy_into_root rootgroup , true,true

	puts 'done'


end
at_exit do
	# reset the working folders - otherwise ICM may not be able to open up next time
	# the problem with this is that one cannot open ICM on the database in root_folder and see results
	# because it does not set the working folder based on masater database location.
	print("resetting working folders")
	WSApplication.set_results_folder(original_results_folder)
	WSApplication.set_working_folder(original_working_folder)
end
